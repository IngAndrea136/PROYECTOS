// boton menu responsive //
document.querySelector('.menu-icon').addEventListener('click', () => {
    document.querySelector('.list').classList.toggle('show');
});

// automatic slider //
var counter = 1;
    setInterval(function(){
      document.getElementById('radio' + counter).checked = true;
      counter++;
      if(counter > 4){
        counter = 1;
      }
    }, 5000);